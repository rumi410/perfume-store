
function updatePriceAndImage() {
  const size = document.getElementById("size").value;
  const price = document.getElementById("price");
  const image = document.getElementById("productImage");

  if (size === "100") {
    price.innerText = "Price: Rs. 1000";
    image.src = "images/perfume1.jpg";
  } else {
    price.innerText = "Price: Rs. 2000";
    image.src = "images/perfume2.jpg";
  }
}
